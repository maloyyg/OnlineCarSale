﻿namespace OnlineCarSale.Web.Models
{
    public class CarSearchModel
    {
        
        public string? CompanyName { get; set; }
        public string? CarModelName { get; set; }
        public int? CarYear { get; set; }
        public decimal? CarPrice { get; set; }
        public string? Location { get; set; }
        public string? CarBodyType { get; set; }
        public string? ListedBy { get; set; }
    }
}
