﻿using System.ComponentModel.DataAnnotations;

namespace OnlineCarSale.Web.Models
{
    public class UserFeedbackModel
    {
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string FeedbackType { get; set; }
        [Required]
        [StringLength(5000, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string FeedbackDescription { get; set; }
    }
}
