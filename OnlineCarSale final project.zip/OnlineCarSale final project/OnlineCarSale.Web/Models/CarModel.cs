﻿using System.ComponentModel.DataAnnotations;

namespace OnlineCarSale.Web.Models
{
    public class CarModel
    {
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string CompanyName { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string CarModelName { get; set; }
        [Required]
        [Range(1922,2022,ErrorMessage = "Car manufactured year should be between 1922 to 2022")]
        public int CarYear { get; set; }
        [Required]
        [Range(0, 9999999999999999.99,ErrorMessage ="Please enter valid car price")]
        public decimal CarPrice { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string Location { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 1)]
        [DataType(DataType.Text)]
        public string CarBodyType { get; set; }
    }
}
