﻿namespace OnlineCarSale.Web.Models.Enum
{
    public enum RoleType
    {
        Seller = 1,
        Buyer = 2,
    }
}
