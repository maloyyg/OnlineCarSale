﻿using OnlineCarSale.Web.Data;
using OnlineCarSale.Web.Data.DataModel;
using OnlineCarSale.Web.Models;
using OnlineCarSale.Web.Services.Interface;
using System.Security.Claims;

namespace OnlineCarSale.Web.Services.Implementation
{
    public class CarRelatedService : ICarRelatedService
    {
        private OnlineCarSaleDbContext _context;
        private IHttpContextAccessor _contextAccessor;

        public CarRelatedService(OnlineCarSaleDbContext context, IHttpContextAccessor contextAccessor)
        {
            _context = context;
            _contextAccessor = contextAccessor;
        }

        public async Task<int> AddCarInsideListing(CarModel carModel)
        {
            try
            {
                
                var userName = _contextAccessor?.HttpContext?.User?.Claims?.FirstOrDefault(a => a.Type == ClaimTypes.NameIdentifier)?.Value;
                
                Car car = new Car()
                { 
                    CarBodyType = carModel.CarBodyType,
                    CarModelName = carModel.CarModelName,
                    CarPrice = carModel.CarPrice,
                    CarYear = carModel.CarYear,
                    CompanyName = carModel.CompanyName,
                    IsDeleted = false,
                    Location = carModel.Location,
                    CreatedDate = DateTime.UtcNow,
                    ListedByUserName = userName
                };

                _context.Cars.Add(car);
                if (await _context.SaveChangesAsync() > 0)
                { 
                    return car.Id;
                }
            }
            catch (Exception ex)
            { 
            
            }
            return 0;
        }

        public async Task<List<CarSearchModel>> SearchCar(CarSearchModel carSearchModel)
        {
            try
            {
                var cars = _context.Cars.Where(a => a.CarYear == (carSearchModel.CarYear ?? a.CarYear) &&
                    a.CarModelName == (carSearchModel.CarModelName ?? a.CarModelName)  &&
                    a.CarBodyType == (carSearchModel.CarBodyType ?? a.CarBodyType) &&
                    a.CompanyName == (carSearchModel.CompanyName ?? a.CompanyName) &&
                    a.Location == (carSearchModel.Location ?? a.Location))
                    .Select(a => new CarSearchModel()
                    {
                        CarYear =a.CarYear,
                        CarBodyType=a.CarBodyType,
                        CarModelName=a.CarModelName,
                        CompanyName=a.CompanyName,
                        CarPrice = a.CarPrice,
                        ListedBy = a.ListedByUserName,
                        Location   = a.Location

                    }).ToList();
                return cars;
            }
            catch (Exception ex)
            { 
            }
            return null;
        }

        public async Task<List<CarSearchModel>> GetCarListing()
        {
            try
            {
                var userName = _contextAccessor?.HttpContext?.User?.Claims?.FirstOrDefault(a => a.Type == ClaimTypes.NameIdentifier)?.Value;
                var cars = _context.Cars.Where(a => a.ListedByUserName == userName)
                    .Select(a => new CarSearchModel()
                    {
                        CarYear = a.CarYear,
                        CarBodyType = a.CarBodyType,
                        CarModelName = a.CarModelName,
                        CompanyName = a.CompanyName,
                        CarPrice = a.CarPrice,
                        ListedBy = a.ListedByUserName,
                        Location = a.Location

                    }).ToList();
                return cars;
            }
            catch (Exception ex)
            { 
            
            }
            return null;
        }
    }
}
