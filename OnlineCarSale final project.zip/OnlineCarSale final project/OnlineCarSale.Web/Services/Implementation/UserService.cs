﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using OnlineCarSale.Web.Common;
using OnlineCarSale.Web.Data;
using OnlineCarSale.Web.Data.DataModel;
using OnlineCarSale.Web.Models;
using OnlineCarSale.Web.Services.Interface;
using System.Security.Claims;
using OnlineCarSale.Web.Models.Enum;

namespace OnlineCarSale.Web.Services.Implementation
{
    public class UserService : IUserService
    {
        private ILogger<UserService> _logger;
        private OnlineCarSaleDbContext _context;
        private IHttpContextAccessor _contextAccessor;
        public UserService(ILogger<UserService> logger, OnlineCarSaleDbContext context, IHttpContextAccessor contextAccessor)
        {
            _logger = logger;
            _context = context;
            _contextAccessor = contextAccessor;
        }

        public async Task<bool> RegisterUser(UserRegistrationModel userRegistrationModel)
        {
            try
            {
                User user = new User()
                {
                    Name = userRegistrationModel.Name,
                    Email = userRegistrationModel.Email,
                    PhoneNumber = userRegistrationModel.PhoneNumber,
                    Address = userRegistrationModel.Address,
                    Username = userRegistrationModel.UserName.Trim(' '),
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow,
                    Password = new List<Password>()
                    { 
                        new Password()
                        {
                            IsDeleted  = false,
                            IsLocked = false,
                            HashPassword = userRegistrationModel.Password.Hash()
                        } 
                    },
                    Role = new List<Role>()
                    {
                        new Role()
                        {
                            RoleType = userRegistrationModel.Role.ToString()
                        }
                    }
                };

                _context.Users.Add(user);
                int numberOfRecord = await _context.SaveChangesAsync();
                if(numberOfRecord == 3)
                {
                    _logger.LogInformation($"User with user id {user.Id} created");
                    return true;
                }
            }
            catch (Exception ex)
            { 
            
            }
            return false;
        }


        public async Task<int> ValidateLoginCredential(UserLoginModel userLoginModel)
        {
            try
            {
                var user = await _context.Users
                    .Where(a => a.Username == userLoginModel.UserName.Trim(' '))
                    .Include(a => a.Password)
                    .Include(a => a.Role)
                    .FirstOrDefaultAsync();

                if (user.Password.FirstOrDefault(a => a.IsLocked == false && a.IsDeleted == false)?.HashPassword == userLoginModel.Password.Hash())
                {
                    var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme, ClaimTypes.Name, ClaimTypes.Role);
                    identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Username));
                    identity.AddClaim(new Claim(ClaimTypes.Name, user.Name));
                    identity.AddClaim(new Claim(ClaimTypes.Email, user.Email));
                    identity.AddClaim(new Claim("userId",user.Id.ToString()));
                    identity.AddClaim(new Claim(ClaimTypes.Role, user.Role?.FirstOrDefault()?.RoleType));
                    //add your own claims 
                    var principal = new ClaimsPrincipal(identity);
                    await _contextAccessor.HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties { IsPersistent = true });
                    RoleType roleType = Enum.Parse<RoleType>(user.Role?.FirstOrDefault()?.RoleType);
                    return (int)roleType;
                }
            }
            catch (Exception ex)
            {
            
            }
            return 0;
        }

        public async Task<int> SaveUserFeedback(UserFeedbackModel userFeedbackModel)
        {
            try
            {
                var userName = _contextAccessor?.HttpContext?.User?.Claims?.FirstOrDefault(a => a.Type == ClaimTypes.NameIdentifier)?.Value;
                var email = _contextAccessor?.HttpContext?.User?.Claims?.FirstOrDefault(a => a.Type == ClaimTypes.Email)?.Value;
                UserFeedback userFeedback = new UserFeedback()
                { 
                    UserName = userName,
                    UserEmail = email,
                    FeedbackType = userFeedbackModel.FeedbackType,
                    FeedbackDescription = userFeedbackModel.FeedbackDescription,
                    IsResolved = false

                };
                _context.UserFeedbacks.Add(userFeedback);
                if (await _context.SaveChangesAsync() > 0)
                {
                    return userFeedback.Id;
                }
            }
            catch (Exception ex)
            { 
            
            }
            return 0;
        }

        public async Task<UserRegistrationModel> GetUser()
        {
            try
            {
                string userIdentifier = _contextAccessor?.HttpContext?.User?.Claims?.FirstOrDefault(a => a.Type == "userId")?.Value;
                int userId = 0;
                if (userIdentifier != null && int.TryParse(userIdentifier, out userId))
                {
                    var user = await _context.Users.Where(a => a.Id == userId).Include(a => a.Role).FirstOrDefaultAsync();
                    UserRegistrationModel userRegistrationModel = new UserRegistrationModel()
                    { 
                        Name = user.Name,
                        Email = user.Email,
                        Role = user.Role.FirstOrDefault().RoleType == RoleType.Seller.ToString() ? RoleType.Seller: RoleType.Buyer,
                        UserName = user.Username,
                        Address = user.Address,
                        PhoneNumber = user.PhoneNumber
                    };
                    return userRegistrationModel;
                }
            }
            catch (Exception ex)
            { 
            
            }
            return null;
        }
    }
}
