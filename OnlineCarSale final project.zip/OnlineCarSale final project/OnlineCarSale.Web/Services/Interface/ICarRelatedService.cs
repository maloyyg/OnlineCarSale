﻿using OnlineCarSale.Web.Models;

namespace OnlineCarSale.Web.Services.Interface
{
    public interface ICarRelatedService
    {
        Task<int> AddCarInsideListing(CarModel carModel);
        Task<List<CarSearchModel>> SearchCar(CarSearchModel carSearchModel);
        Task<List<CarSearchModel>> GetCarListing();
    }
}
