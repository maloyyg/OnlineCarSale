﻿using OnlineCarSale.Web.Models;

namespace OnlineCarSale.Web.Services.Interface
{
    public interface IUserService
    {
        Task<bool> RegisterUser(UserRegistrationModel userRegistrationModel);
        Task<int> ValidateLoginCredential(UserLoginModel userLoginModel);
        Task<int> SaveUserFeedback(UserFeedbackModel userFeedbackModel);
        Task<UserRegistrationModel> GetUser();
    }
}
