﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnlineCarSale.Web.Migrations
{
    public partial class updatecartable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ListedByUserId",
                table: "Cars");

            migrationBuilder.AddColumn<string>(
                name: "ListedByUserName",
                table: "Cars",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ListedByUserName",
                table: "Cars");

            migrationBuilder.AddColumn<int>(
                name: "ListedByUserId",
                table: "Cars",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
