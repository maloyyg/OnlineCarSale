﻿using Microsoft.EntityFrameworkCore;
using OnlineCarSale.Web.Data.DataModel;

namespace OnlineCarSale.Web.Data
{
    public class OnlineCarSaleDbContext : DbContext
    {
        public OnlineCarSaleDbContext(DbContextOptions<OnlineCarSaleDbContext> options)
            : base(options) 
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Password>()
                .HasOne(a => a.User)
                .WithMany(b => b.Password)
                .HasForeignKey(c => c.UserId);

            modelBuilder.Entity<Role>()
                .HasOne(a => a.User)
                .WithMany(b => b.Role)
                .HasForeignKey(c => c.UserId);
        
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Password> Passwords { get; set; }
        public DbSet<Car> Cars { get; set; }
        public DbSet<UserFeedback> UserFeedbacks { get; set; }
    }
}
