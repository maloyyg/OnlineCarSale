﻿namespace OnlineCarSale.Web.Data.DataModel
{
    public class Role
    {
        public int Id { get; set; }
        public string RoleType { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
    }
}
