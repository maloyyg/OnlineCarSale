﻿namespace OnlineCarSale.Web.Data.DataModel
{
    public class Car
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string CarModelName { get; set; }
        public int CarYear { get; set; }
        public decimal CarPrice { get; set; }
        public string Location { get; set; }
        public string CarBodyType { get; set; }
        public string ListedByUserName { get; set; } 
        public bool IsDeleted { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
