﻿namespace OnlineCarSale.Web.Data.DataModel
{
    public class UserFeedback
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string FeedbackType { get; set; }
        public string FeedbackDescription { get; set; }
        public bool IsResolved { get; set; }
    }
}
