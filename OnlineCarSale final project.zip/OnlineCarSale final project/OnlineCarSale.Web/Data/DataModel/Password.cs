﻿namespace OnlineCarSale.Web.Data.DataModel
{
    public class Password
    {
        public int Id { get; set; }
        public string HashPassword{ get; set; }
        public bool IsDeleted { get; set; }
        public bool IsLocked { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
    }
}
