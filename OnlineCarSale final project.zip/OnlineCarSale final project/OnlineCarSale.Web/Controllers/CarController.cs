﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineCarSale.Web.Models;
using OnlineCarSale.Web.Models.Enum;
using OnlineCarSale.Web.Services.Interface;

namespace OnlineCarSale.Web.Controllers
{
    [Authorize]
    public class CarController : Controller
    {
        private ICarRelatedService _carRelatedService;

        public CarController(ICarRelatedService carRelatedService)
        { 
            _carRelatedService = carRelatedService;
        }

        [Authorize(Roles = "Seller")]
        public IActionResult Add()
        {
            return View();
        }

        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> AddCarPost(CarModel carModel)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Error = "Please provide all valid details and try again";
                return View("Add", carModel);
            }
            else
            { 
                var listingId = await _carRelatedService.AddCarInsideListing(carModel);
                if (listingId == 0)
                {
                    ViewBag.Error = "Please provide all valid details and try again";
                    return View("Add", carModel);
                }
                else
                {
                    return View(listingId);
                }
            }
            
        }

        [Authorize(Roles = "Buyer")]
        public IActionResult Search()
        {
            return View();
        }

        [Authorize(Roles = "Buyer")]
        [HttpPost]
        public async Task<IActionResult> GetCarDetail(CarSearchModel carSearchModel)
        {
            var cars = await _carRelatedService.SearchCar(carSearchModel);

            return View(cars);
        }


        [Authorize(Roles = "Seller")]
        public async Task<IActionResult> ViewList()
        {
            var cars = await _carRelatedService.GetCarListing();
            return View("GetCarDetail",cars);
        }
    }
}
