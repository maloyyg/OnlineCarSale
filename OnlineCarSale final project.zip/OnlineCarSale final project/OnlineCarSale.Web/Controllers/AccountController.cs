﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using OnlineCarSale.Web.Models;
using OnlineCarSale.Web.Models.Enum;
using OnlineCarSale.Web.Services.Interface;

namespace OnlineCarSale.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserService _userService;
        private readonly ILogger<AccountController> _logger;
        public AccountController(IUserService userService,ILogger<AccountController> logger)
        { 
            _userService = userService;
            _logger = logger;
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegisterUser(UserRegistrationModel userRegistrationModel)
        {
            if (ModelState.IsValid)
            {
                bool isSuccess = await _userService.RegisterUser(userRegistrationModel);
                if (isSuccess)
                {
                    ViewBag.Success = true;
                }
                else
                {
                    ViewBag.Error = "Error occured while saving details to database";
                }
            }
            else
            {
                ViewBag.Error = "Input details are not valid";
            }
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> LoginUser(UserLoginModel userLoginModel)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Error = "User credential is not valid";
                return View("Login", userLoginModel);
            }
            else
            {
                int responseType = await _userService.ValidateLoginCredential(userLoginModel);
                if (responseType > 0)
                {
                    
                    if (responseType == (int)RoleType.Seller)
                    {
                        return RedirectToAction("Add", "Car");
                    }
                    else
                    {
                        return RedirectToAction("Search", "Car");
                    }
                }
                else
                {
                    ViewBag.Error = "User credential is not valid";
                    return View("Login", userLoginModel);
                }
            }

            
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> ViewUser()
        {
            var user = await _userService.GetUser();
            return View(user);
        }

        [HttpGet]
        public IActionResult SaveFeedback()
        { 
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SaveFeedbackPost(UserFeedbackModel userFeedbackModel)
        {

            int trackingId = await _userService.SaveUserFeedback(userFeedbackModel);
            return View(trackingId);
        }
    }
}
